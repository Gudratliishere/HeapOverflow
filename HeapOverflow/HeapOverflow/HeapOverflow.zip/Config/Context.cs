﻿using HeapOverflow.DAO.Impl;
using HeapOverflow.DAO.Impl.RAM;
using HeapOverflow.DAO.Inter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HeapOverflow.Config
{
    public class Context
    {
        private static IAdminDAO adminDAO = null;
        private static IUserLoginDAO userLoginDAO = null;
        private static IUsersDAO usersDAO = null;
        private static IRoleDAO roleDAO = null;
        private static IPostDAO postDAO = null;
        private static ICommentDAO commentDAO = null;
        private static IVotesDAO votesDAO = null;

        public static IAdminDAO GetAdminDAO ()
        {
            if (adminDAO == null)
                adminDAO = new AdminRAMDAO();

            return adminDAO;
        }

        public static IUserLoginDAO GetUserLoginDAO ()
        {
            if (userLoginDAO == null)
                userLoginDAO = new UserLoginRAMDAO();

            return userLoginDAO;
        }

        public static IUsersDAO GetUsersDAO ()
        {
            if (usersDAO == null)
                usersDAO = new UsersRAMDAO();

            return usersDAO;
        }

        public static IRoleDAO GetRoleDAO ()
        {
            if (roleDAO == null)
                roleDAO = new RoleRAMDAO();

            return roleDAO;
        }

        public static IPostDAO GetPostDAO()
        {
            if (postDAO == null)
                postDAO = new PostRAMDAO();

            return postDAO;
        }

        public static ICommentDAO GetCommentDAO ()
        {
            if (commentDAO == null)
                commentDAO = new CommentRAMDAO();

            return commentDAO;
        }

        public static IVotesDAO GetVotesDAO ()
        {
            if (votesDAO == null)
                votesDAO = new VotesDAO();

            return votesDAO;
        }
    }
}